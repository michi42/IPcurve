#include "profile.h"
#include <fstream>
/*struct GameProfile {
	int timeout;
	int gameSpeed;
	int enableSpecials;
	int enableHoles;
	int holeDist;
	int holeRnd;
	double turnAngle;
	double holeSize;
};*/

//typedef std::vector<GameProfile> GameProfileList;
using namespace std;

GameProfiler::GameProfiler()
{
	fstream stream((aux::config_path+PROFILE_FILE).c_str(),ios_base::in);
	if(stream) {
		int count;
		stream >> count;
		for(int i=0;i<count;i++) {
			GameProfile p;
			stream >> p.name;
			aux::str_revertSpaces(p.name);
			stream >> p.timeout;
			stream >> p.gameSpeed;
			stream >> p.enableSpecials;
			stream >> p.enableHoles;
			stream >> p.holeDist;
			stream >> p.holeRnd;
			stream >> p.turnAngle;
			stream >> p.holeSize;
			profiles.push_back(p);
		}
	}
	stream.close();
}

GameProfiler::~GameProfiler()
{
	fstream stream((aux::config_path+PROFILE_FILE).c_str(),ios_base::out|ios_base::trunc);
	if(stream) {
		int count = profiles.size();
		stream << count << endl;
		for(int i=0;i<count;i++) {
			GameProfile p = profiles[i];
			aux::str_replaceSpaces(p.name);
			stream << p.name << endl;
			stream << p.timeout << endl;
			stream << p.gameSpeed << endl;
			stream << p.enableSpecials << endl;
			stream << p.enableHoles << endl;
			stream << p.holeDist << endl;
			stream << p.holeRnd << endl;
			stream << p.turnAngle << endl;
			stream << p.holeSize << endl;
		}
	}
	stream.close();
}

GameProfileList* GameProfiler::getProfiles()
{
	return &profiles;
}

GameProfile* GameProfiler::getProfile(std::string name)
{
	GameProfileList::iterator it = profiles.begin();
	while(it != profiles.end()) {
		if(name == (*it).name)
			return &(*it);
		++it;
	}
	return 0;
}

void GameProfiler::deleteProfile(std::string name)
{
	GameProfileList::iterator it = profiles.begin();
	while(it != profiles.end()) {
		if(name == (*it).name)
			it = profiles.erase(it);
		else
			++it;
	}
}

void GameProfiler::addProfile(const GameProfile& profile)
{
	profiles.push_back(profile);
}
