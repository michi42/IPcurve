#ifndef METASERVER_H
#define METASERVER_H
#include <stdio.h>
#include <string>
#include <vector>
#include <enet/enet.h>
#include "config.h"

class CServerInfo{
	public:
		CServerInfo(unsigned int Ip, short Port, std::string Name, std::string Desc, bool pass);
		~CServerInfo();
		bool checkServer();
		unsigned int ip;
		short port;
		std::string name;
		std::string desc;
		ENetHost* sock;
		ENetPeer* peer;
		bool connected;
		bool password;
		int time;
};

class CMetaserver{
	public:
		CMetaserver();
		~CMetaserver();
		void listen();
		void update(int timeout = METASERVERS_TIMEOUT);
	private:
		std::vector<CServerInfo*> servers;
		ENetHost* socket;
};

#endif
