#include <stdio.h>
#include <string>
#include <enet/enet.h>
#include "config.h"
#include "message.h"
#include "metaserver.h"

CServerInfo::CServerInfo(unsigned int Ip, short Port, std::string Name)
{
	ip = Ip;
	port = Port;
	name = Name;
	time = 0;
	
	peer = 0;
	sock = enet_host_create(0,1,0,0);
	if(sock == 0)
		return;
	
	ENetAddress addr;
	addr.host = ip;
	addr.port = Port;
	
	ENetEvent event;
	bool success = false;
	
	peer = enet_host_connect(sock,&addr,1);
	
	if(peer == 0)
		success = false;
	else{
		if(enet_host_service(sock, &event, METASERVERS_CHECK_TIMEOUT) <= 0 ||
		  event.type != ENET_EVENT_TYPE_CONNECT) {
			enet_peer_reset(peer);
			peer = 0;
			success = false;
		}else{
			MessageMetaserverPing ping;
			ENetPacket* packet = enet_packet_create(&ping,
					sizeof(ping),
					ENET_PACKET_FLAG_RELIABLE);
			enet_peer_send(peer, 0, packet);
			enet_host_flush(sock);
			success = true;
		}
	}
	
	if(!success){
		enet_host_destroy(sock);
		sock = 0;
		peer = 0;
	}
}

CServerInfo::~CServerInfo()
{
	if(peer!=0){
		enet_peer_disconnect(peer,0);
		enet_peer_reset(peer);
	}
	if(sock!=0)
		enet_host_destroy(sock);
	sock = 0;
}

bool CServerInfo::checkServer()
{
	if(peer==0||sock==0){
		printf("server %s is unreachable (firewall?)\n",name.c_str());
		return false;
	}
	time++;
	ENetEvent event;
	while(enet_host_service (sock, &event, 1) > 0)
	{
		if(event.type==ENET_EVENT_TYPE_RECEIVE){
			MessageBase* base = (MessageBase*)event.packet->data;
			if(base->mtype==MESSAGE_METASERVER_PING){
				MessageMetaserverPing* req = (MessageMetaserverPing*)event.packet->data;
				if(req->version==VERSION){
					time = 0;
					MessageMetaserverPing ping;
					ENetPacket* packet = enet_packet_create(&ping,
							sizeof(ping),
							ENET_PACKET_FLAG_RELIABLE);
					enet_peer_send(peer, 0, packet);
					enet_host_flush(sock);
				}
			}
			enet_packet_destroy(event.packet);
			break;
		}else if(event.type==ENET_EVENT_TYPE_DISCONNECT){
			printf("The server %s kicked us out, so let's kick him from meta...\n",name.c_str());
			return false;
		}
	}
	if(time>METASERVERS_CLIENT_TIMEOUT){
		printf("just timin' out: %s \n",name.c_str());
		return false;
	}
	return true;
}

CMetaserver::CMetaserver()
{
	printf("This is IPCurve Metaserver, version %x\n",VERSION);
	socket = 0;
}

CMetaserver::~CMetaserver()
{
	if(socket!=0){
		enet_host_destroy(socket);
	}
}

void CMetaserver::listen()
{
	ENetAddress addr;
	addr.host = ENET_HOST_ANY;
	addr.port = METASERVER_PORT;
	socket = enet_host_create(&addr,METASERVERS_CONNECTIONS,0,0);
	servers.clear();
	printf("Awaiting connections...\n");
}

void CMetaserver::update(int timeout)
{
	std::vector<CServerInfo*>::iterator it  = servers.begin();
	while(it != servers.end()){
		CServerInfo* inf = *it;
		if(inf==0){
			servers.erase(it);
			continue;
		}
		if(!inf->checkServer()){
			printf("timed out: %s\n",inf->name.c_str());
			servers.erase(it);
			delete inf;
		}else{
			++it;
		}
	}
	ENetEvent event;
	while(enet_host_service (socket, &event, timeout) > 0)
	{
		if(event.type==ENET_EVENT_TYPE_RECEIVE){
			MessageBase* base = (MessageBase*)event.packet->data;
			unsigned char parts[4];
			if(base->mtype==MESSAGE_METASERVER_REQUEST){
				MessageMetaserverRequest* req = (MessageMetaserverRequest*)event.packet->data;
				MessageMetaserverReply rep;
				for(int i=0;i<servers.size();i++){
					if(req->version!=VERSION){
						sprintf(rep.server,"Your client is <br> OUT OF DATE");
						i=servers.size()-1;
					}else{
						parts[0] = ((servers[i]->ip)&0xFF000000)>>24;
						parts[1] = ((servers[i]->ip)&0x00FF0000)>>16;
						parts[2] = ((servers[i]->ip)&0x0000FF00)>>8;
						parts[3] = ((servers[i]->ip)&0x000000FF);
						if(parts[3]==127&&parts[2]==0&&parts[1]==0&&parts[0]==1){
							sprintf(rep.server, "%s <br> ozone.game-host.org   %d",servers[i]->name.c_str(),servers[i]->port);
						}else{
							sprintf(rep.server, "%s <br> %d.%d.%d.%d   %d",servers[i]->name.c_str(),parts[3],parts[2],parts[1],parts[0],servers[i]->port);
						}
					}
					ENetPacket* packet = enet_packet_create(&rep,
							sizeof(rep),
							ENET_PACKET_FLAG_RELIABLE);
					enet_peer_send(event.peer, 0, packet);
				}
				enet_host_flush(socket);
				enet_peer_disconnect(event.peer,0);
			}else if(base->mtype==MESSAGE_METASERVER_ADDSERVER){
				MessageMetaserverAddServer* add = (MessageMetaserverAddServer*)event.packet->data;
				if(add->version==VERSION){
					MessageMetaserverAck ack;
					ENetPacket* packet = enet_packet_create(&ack,
							sizeof(ack),
							ENET_PACKET_FLAG_RELIABLE);
					enet_peer_send(event.peer, 0, packet);
					enet_host_flush(socket);
					enet_peer_disconnect(event.peer,0);
					bool isDup = false;
					std::vector<CServerInfo*>::iterator it  = servers.begin();
					std::string str = add->serverName;
					while(it != servers.end()){
						CServerInfo* inf = *it;
						if(inf==0)
							continue;
						if(inf->ip==event.peer->address.host && inf->name==str){
							printf("duplicate register from %s\n",inf->name.c_str());
							isDup = true;
						}
						++it;
					}
					if(!isDup){
						servers.push_back(new CServerInfo(event.peer->address.host,add->port,std::string(add->serverName)));
						parts[0] = ((event.peer->address.host)&0xFF000000)>>24;
						parts[1] = ((event.peer->address.host)&0x00FF0000)>>16;
						parts[2] = ((event.peer->address.host)&0x0000FF00)>>8;
						parts[3] = ((event.peer->address.host)&0x000000FF);
						printf("registered %s from %d.%d.%d.%d (port %d)\n",add->serverName,parts[3],parts[2],parts[1],parts[0],add->port);
					}
				}
			}else if(base->mtype==MESSAGE_METASERVER_REMOVESERVER){
				MessageMetaserverRemoveServer* rem = (MessageMetaserverRemoveServer*)event.packet->data;
				if(rem->version==VERSION){
					std::vector<CServerInfo*>::iterator it  = servers.begin();
					while(it != servers.end()){
						CServerInfo* inf = *it;
						if(inf==0){
							servers.erase(it);
							continue;
						}
						std::string str = rem->serverName;
						if(inf->ip==event.peer->address.host && inf->name==str){
							printf("de-registered %s\n",inf->name.c_str());
							servers.erase(it);
							delete inf;
						}else{
							++it;
						}
					}
				}
				enet_peer_disconnect(event.peer,0);
			}
			enet_packet_destroy(event.packet);
		}
	}
}


